<?php
global $product;
$id = get_the_ID();
if ( is_product() ) {
	$product = new WC_Product( get_the_ID() );
}

if( is_cart() ) {
	$cart_items = stm_get_cart_items();
	$id = $cart_items['car_class']['id'];
	$product = new WC_Product( $id );
}

if($product == null) return;

$hasGallery = ( !empty( $product->get_gallery_image_ids() ) ) ? array_chunk( $product->get_gallery_image_ids(), 3 ) : array();
$prodAtts = stm_mcr_get_product_atts( $product );

$excerpt = get_the_excerpt( $id );

$current_car = stm_get_cart_items();

$current_car_id = 0;

if ( !empty( $current_car['car_class'] ) ) {
    if ( !empty( $current_car['car_class']['id'] ) ) {
        $current_car_id = $current_car['car_class']['id'];
    }
}

$current_car = '';
if ( $id == $current_car_id ) {
    $current_car = 'current_car';
}

$dates = ( isset( $_COOKIE['stm_calc_pickup_date_' . get_current_blog_id()] ) ) ? stm_checkOrderAvailable( $id, urldecode( $_COOKIE['stm_calc_pickup_date_' . get_current_blog_id()] ), urldecode( $_COOKIE['stm_calc_return_date_' . get_current_blog_id()] ) ) : array();

$disableCar = ( count( $dates ) > 0 ) ? 'stm-disable-car' : '';

$invisibleBlockId = 'stm-invisible-' . rand( 100, 100000 );
?>

<div class="col-md-6 col-sm-12">
    <div class="smt-cr-grid-loop-wrap stm-cr-reservation-page <?php echo esc_attr( $invisibleBlockId ); ?> <?php echo esc_attr( $disableCar ) ?>"
         id="product-<?php echo esc_attr( $id ); ?>">
        <div class="reserv-visible-block">
            <div class="reserv-car-info-wrap">
                <div class="car-info-top">
                    <div class="car-preview-img">
                        <?php if ( has_post_thumbnail() ): ?>
                            <div class="image">
                                <?php the_post_thumbnail( 'stm-img-350-181', array( 'class' => 'img-responsive' ) ); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="car-data">
                        <?php if ( isset( $prodAtts['attribute_pa_vehicle-class'] ) ) : ?>
                            <div class="car-class-wrap">
                                <div class="car-class">
                                    <?php echo $prodAtts['attribute_pa_vehicle-class']['value']; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        <h3><?php the_title(); ?></h3>
                        <div class="stm-mcr-similat-text"><?php echo esc_html__('or similar', 'stm_motors_car_rental'); ?></div>
                    </div>
                </div>
                <div class="car-info-middle">
                    <?php if ( !empty( $disableCar ) ): ?>
                        <div class="stm-enable-car-date">
                            <?php
                            $formatedDates = array();
                            foreach ( $dates as $val ) {
                                $formatedDates[] = stm_get_formated_date( $val, 'd M' );
                            }
                            ?>
                            <h3><?php echo esc_html__( 'This Class is already booked in: ', 'stm_motors_car_rental' ) . "<span class='yellow'>" . implode( '<span>,</span> ', $formatedDates ); ?></span>
                                .</h3>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="car-info-bottom">
                <ul>
                    <?php
                    $i=0;
                    foreach ( $prodAtts as $attr ) {
                        if ( $attr['show'] && $i<3) {
                            ?>
                            <li>
                                <div class="attr-img">
                                    <img src="<?php echo esc_url( $attr['img'] ); ?>"/>
                                </div>
                                <div class="attr-value">
                                    <?php echo apply_filters( 'stm_mcr_lmth', $attr['value'] ); ?>
                                </div>
                            </li>
                        <?php
                        $i++;
                        }
                    } ?>
                    <li class="view-all-specific" data-invis="<?php echo esc_attr( $invisibleBlockId ); ?>"
                        data-tab="<?php echo esc_attr( 'specific-' . $id ); ?>">
                        <i class="fa fa-chevron-right"></i>
                        <span><?php echo esc_html__( 'View All Specifications', 'stm_motors_car_rental' ); ?></span>
                    </li>
                </ul>
            </div>
            <div class="reserv-price-wrap">
                <?php stm_car_rental_load_template( 'shop/parts/price-view', array( 'is_add_to_cart' => false, 'invis_id' => $invisibleBlockId ) ); ?>
            </div>
        </div>
        <?php
        $extraOpt = 'extra-opt-' . $id;
        $terms = 'terms-' . $id;
        $specific = 'specific-' . $id;
        $gallery = 'gallery-' . $id;
        $comments = 'comments-' . $id;
        ?>
        <div id="<?php echo esc_attr( $invisibleBlockId ); ?>" class="reserv-invisible-block">
            <div class="tabs-wrapper">
                <ul class="nav nav-tabs owl-carousel" id="myTab<?php echo '-' . $id; ?>" role="tabreserv">
                    <li class="nav-item active">
                        <a class="nav-link" id="<?php echo esc_attr( $extraOpt ); ?>-tab" data-toggle="tab"
                           href="#<?php echo esc_attr( $extraOpt ); ?>" role="tab"
                           aria-controls="<?php echo esc_attr( $extraOpt ); ?>" aria-selected="true">
                            <?php echo esc_html__( 'Extra Options', 'stm_motors_car_rental' ) ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="<?php echo esc_attr( $terms ); ?>-tab" data-toggle="tab"
                           href="#<?php echo esc_attr( $terms ); ?>" role="tab"
                           aria-controls="<?php echo esc_attr( $terms ); ?>" aria-selected="false">
                            <?php echo esc_html__( 'Rental Terms', 'stm_motors_car_rental' ) ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="<?php echo esc_attr( $specific ); ?>-tab" data-toggle="tab"
                           href="#<?php echo esc_attr( $specific ); ?>" role="tab"
                           aria-controls="<?php echo esc_attr( $specific ); ?>" aria-selected="false">
                            <?php echo esc_html__( 'All Specifications', 'stm_motors_car_rental' ) ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="<?php echo esc_attr( $gallery ); ?>-tab" data-toggle="tab"
                           href="#<?php echo esc_attr( $gallery ); ?>" role="tab"
                           aria-controls="<?php echo esc_attr( $gallery ); ?>" aria-selected="false">
                            <?php echo esc_html__( 'Image Gallery', 'stm_motors_car_rental' ) ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="<?php echo esc_attr( $comments ); ?>-tab" data-toggle="tab"
                           href="#<?php echo esc_attr( $comments ); ?>" role="tab"
                           aria-controls="<?php echo esc_attr( $comments ); ?>" aria-selected="false">
                            <?php echo esc_html__( 'Comments', 'stm_motors_car_rental' ) ?>
                        </a>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade active in" id="<?php echo esc_attr( $extraOpt ); ?>" role="tabpanel"
                         aria-labelledby="<?php echo esc_attr( $extraOpt ); ?>-tab">
                        <?php stm_car_rental_load_template( 'shop/tabs/car-options', array( 'invisId' => $invisibleBlockId ) ) ?>
                    </div>
                    <div class="tab-pane fade" id="<?php echo esc_attr( $terms ); ?>" role="tabpanel"
                         aria-labelledby="<?php echo esc_attr( $terms ); ?>-tab">
                        <?php
                        $excerpt = get_the_excerpt( $id );
                        echo apply_filters( 'the_content', $excerpt );
                        ?>
                    </div>
                    <div class="tab-pane fade" id="<?php echo esc_attr( $specific ); ?>" role="tabpanel"
                         aria-labelledby="<?php echo esc_attr( $specific ); ?>-tab">
                        <?php stm_car_rental_load_template( 'shop/tabs/specifications', $prodAtts ); ?>
                    </div>
                    <div class="tab-pane fade" id="<?php echo esc_attr( $gallery ); ?>" role="tabpanel"
                         aria-labelledby="<?php echo esc_attr( $gallery ); ?>-tab">
						<?php
                        if($hasGallery) {
							stm_car_rental_load_template( 'shop/tabs/gallery', $hasGallery );
						} else {
                            echo '<h3>' . esc_html__('No Images', 'stm_motors_car_rental') . '</h3>';
                        }
                        ?>
                    </div>
                    <div class="tab-pane fade" id="<?php echo esc_attr( $comments ); ?>" role="tabpanel"
                         aria-labelledby="<?php echo esc_attr( $comments ); ?>-tab">
                        <?php
                        if ( function_exists( 'wc_get_template_part' ) ) {
                            wc_get_template_part( 'single-product-reviews' );
                        }
                        ?>
                    </div>
                </div>
            </div>
            <div class="add-to-cart-btns">
                <?php stm_car_rental_load_template( 'shop/parts/price-view', array( 'is_add_to_cart' => true ) ); ?>
            </div>
        </div>
    </div>
</div>
<script>
    (function($) {
        $(document).ready(function() {
            $('.nav-tabs').owlCarousel({
                items: 2,
                dots: false,
                center: false,
                autoWidth: true,
                touchDrag: false,
                mouseDrag: false,
            });
        });

        $('.nav-link').on('click', function() {
            $('.nav-tabs').find('.nav-item').removeClass('active');
        });
    })(jQuery)
</script>