<?php
$link = stm_c_f_get_page_url('account_page');
?>

<div class="profile-wrap">
    <div class="lOffer-account-unit">
        <a href="<?php echo esc_url($link); ?>" class="lOffer-account">
            <?php
            if(is_user_logged_in()): $user_fields = stm_get_user_custom_fields('');
                if(!empty($user_fields['image'])):
                    ?>
                    <div class="stm-dropdown-user-small-avatar">
                        <img src="<?php echo esc_url($user_fields['image']); ?>" class="im-responsive"/>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            <i class="stm-service-icon-user"></i>
        </a>
        <?php stm_c_f_load_template('header/parts/account-dropdown') ; ?>
    </div>
</div>

