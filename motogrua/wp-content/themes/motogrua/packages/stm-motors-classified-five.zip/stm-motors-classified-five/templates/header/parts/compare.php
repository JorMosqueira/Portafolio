<?php
$compare_page = \uListing\Classes\StmListingSettings::getPages("compare_page");

if ($compare_page):

    $compareCookie = (!empty($_COOKIE['ulisting_compare'])) ? (array) $_COOKIE['ulisting_compare'] : array();

?>
<div class="stm-compare">
    <a class="lOffer-compare" href="<?php echo esc_url(get_the_permalink($compare_page)); ?>"
       title="<?php esc_attr_e('Watch compared', 'motors'); ?>">
        <i class="stm-all-icon-listing-compare"></i>
        <span class="list-badge">
            <span class="stm-current-cars-in-compare">
                <?php if (!empty($compareCookie) and count($compareCookie)) {
                    echo esc_attr(count($compareCookie));
                } ?>
            </span>
        </span>
    </a>
</div>
<?php endif; ?>