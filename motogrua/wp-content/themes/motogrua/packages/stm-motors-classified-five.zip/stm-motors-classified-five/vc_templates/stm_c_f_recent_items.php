<?php
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$css_class = (!empty($css)) ? apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class($css, ' ')) : '';

stm_c_f_module_enqueue_scripts_styles('stm_c_f_recent_items');

$allObj = array();
$models = array();

$allPosts = new WP_Query(
	array(
		'post_type' => 'listing',
		'posts_per_page' => $posts_per_page,
		'post_status' => 'publish',
		'order' => 'DESC'
	)
);

if($allPosts->have_posts()) {
	while ($allPosts->have_posts()) {
		$allPosts->the_post();
		$model = uListing\Classes\StmListing::load(get_post());
		$models[] = $model;
	}

	$allObj = ['query' => $allPosts, 'models' => $models];
	wp_reset_postdata();
}

?>

<div class="stm-c-f-recent-items-wrap">
	<div class="top-wrap <?php echo (!empty($show_as_carousel) && $show_as_carousel == 'yes') ? 'show-nav-carousel' : ''; ?>">
		<h2><?php echo esc_html($recent_title); ?></h2>
		<div class="actions-wrap">
			<a href="" class="heading-font"><?php echo esc_html__('View all', 'stm_motors_classified_five'); ?></a>
            <?php if(!empty($show_as_carousel) && $show_as_carousel == 'yes') :?>
                <div class="stm-nav">
                    <div class="stm-recent-prev">
                        <i class="stm-all-icon-arrow-left1"></i>
                    </div>
                    <div class="stm-recent-next">
                        <i class="stm-all-icon-arrow-right1"></i>
                    </div>
                </div>
            <?php endif; ?>
		</div>
	</div>
	<div class="recent-items-wrap <?php echo (!empty($show_as_carousel) && $show_as_carousel == 'yes') ? 'as-carousel' : ''; ?>">
		<?php
		uListing\Classes\StmListingTemplate::load_template(
			'listing/ulisting-grid-item',
			[
				"listings" => $allObj['models'],
				"view_type" => 'grid',
				"item_class" => 'stm-c-f-recent-item',
			], true);
		?>
	</div>
</div>
<?php if(!empty($show_as_carousel) && $show_as_carousel == 'yes') :?>
<script type="text/javascript">
    (function($){
        $(document).ready(function (){

            var owlRecent = $('.as-carousel .stm-row-override');

            owlRecent.owlCarousel({
                items: 4,
                loop: true,
                nav: false,
                dots: false,
                margin: 30,
                responsive: {
                    0: {
                        items: 1
                    },
                    450: {
                        items: 2,
                    },
                    768: {
                        items: 3,
                    },
                    1024: {
                        items: 4,
                    }
                }
            });

            $('.stm-recent-prev').on('click', function () {
                owlRecent.trigger('prev.owl.carousel', [300]);
            });
            $('.stm-recent-next').on('click', function () {
                owlRecent.trigger('next.owl.carousel');
            });
        });
    })(jQuery);
</script>
<?php endif; ?>
